var isReady = false;
var _data = null;

google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(function(){
  isReady = true;
  if(_data){
    drawChart();
  }
});

function start(data){      
  _data = data;
  if(isReady){
    drawChart();
  }
}

function drawChart() {
  var data = google.visualization.arrayToDataTable(_data);

  var options = {
    title: 'Company Performance'
  };

  var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
  chart.draw(data, options);
}